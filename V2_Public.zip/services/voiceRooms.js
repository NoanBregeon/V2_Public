// services/voiceRooms.js
const { ChannelType, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const STORE = path.join(__dirname, '../data/voiceRooms.json');

// =======================
//   PERSISTENCE
// =======================
function loadStore() {
  try {
    return JSON.parse(fs.readFileSync(STORE, 'utf8'));
  } catch {
    return { rooms: {} }; // { [channelId]: { owner, created } }
  }
}

let store = loadStore();

function saveStore() {
  try {
    fs.writeFileSync(STORE, JSON.stringify(store, null, 2), 'utf8');
  } catch (e) {
    console.error('❌ voiceRooms saveStore error:', e?.message || e);
  }
}

function registerRoom(channelId, ownerId) {
  store.rooms[channelId] = {
    owner: ownerId,
    created: Date.now()
  };
  saveStore();
}

function unregisterRoom(channelId) {
  if (store.rooms[channelId]) {
    delete store.rooms[channelId];
    saveStore();
  }
}

// =======================
//   API PUBLIQUE
// =======================

function isOwner(channelId, userId) {
  const room = store.rooms[channelId];
  return !!(room && room.owner === userId);
}

async function transferOwnership(channel, newOwnerId) {
  const room = store.rooms[channel.id];
  if (!room) throw new Error('Ce salon n’est pas géré comme vocal temporaire.');

  const oldOwnerId = room.owner;
  room.owner = newOwnerId;
  saveStore();

  // Optionnel : mettre à jour des permissions côté Discord
  try {
    await channel.permissionOverwrites.edit(newOwnerId, {
      ManageChannels: true,
      Connect: true,
      ViewChannel: true
    });

    if (oldOwnerId) {
      await channel.permissionOverwrites.edit(oldOwnerId, {
        ManageChannels: null
      });
    }
  } catch {
    // on ignore les erreurs de perms
  }
}

// =======================
//   EVENT VOICE
// =======================

async function onVoiceStateUpdate(oldState, newState) {
  try {
    const guild = newState.guild || oldState.guild;
    const member = newState.member || oldState.member;
    if (!guild || !member) return;
    if (member.user.bot) return;

    const createId = process.env.CREATE_VOICE_CHANNEL_ID;
    const categoryId = process.env.VOICE_CATEGORY_ID;
    if (!createId || !categoryId) return;

    const oldCh = oldState.channel;
    const newCh = newState.channel;

    // ==========
    // JOIN SALON "CRÉER VOCAL"
    // ==========
    if (
      newCh &&
      newCh.id === createId &&
      (!oldCh || oldCh.id !== createId)
    ) {
      const category = guild.channels.cache.get(categoryId);
      if (!category || category.type !== ChannelType.GuildCategory) {
        console.warn('[voiceRooms] VOICE_CATEGORY_ID invalide.');
        return;
      }

      const baseName =
        member.displayName ||
        member.user.globalName ||
        member.user.username ||
        'Salon';
      const name = `🔊 ${baseName}`.slice(0, 90);

      const created = await guild.channels.create({
        name,
        type: ChannelType.GuildVoice,
        parent: categoryId,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ViewChannel]
          },
          {
            id: member.id,
            allow: [
              PermissionFlagsBits.Connect,
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.ManageChannels
            ]
          }
        ]
      });

      registerRoom(created.id, member.id);

      await member.voice.setChannel(created).catch(() => {});
    }

    // ==========
    // LEAVE / CLEANUP
    // ==========
    if (
      oldCh &&
      oldCh.id !== createId &&
      oldCh.type === ChannelType.GuildVoice
    ) {
      const isTracked = !!store.rooms[oldCh.id];
      if (isTracked && oldCh.parentId === categoryId && oldCh.members.size === 0) {
        unregisterRoom(oldCh.id);
        await oldCh.delete('Salon vocal temporaire vide').catch(() => {});
      }
    }
  } catch (e) {
    console.error('❌ voiceRooms onVoiceStateUpdate:', e?.message || e);
  }
}

module.exports = {
  onVoiceStateUpdate,
  isOwner,
  transferOwnership
};
